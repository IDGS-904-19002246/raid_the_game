
if you want to edit the C3P file. 
you must have Construct 3 Personal edition

if you want to edit the CAPX file. 
you must have Construct 2 Personal edition

dont reupload this game for sell

you can changes the graphic and edit the source

convert to android or ios you must compile use cocon.io https://cocoon.io/


have any questions please contact : gco689657@gmail.com

more games : https://codecanyon.net/user/gamecoutz